// Olaf Surgut 345615
int receive_icmp_echo(int, char [][20], int*, int*, int, int);